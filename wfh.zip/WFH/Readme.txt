This replicates everything in the paper "Does working from home work: evidence from a Chinese Experiment?"


To execute simply run this file in the same directory as all the data


For questions please contact Nick Bloom on nbloom@stanford 


November 2014
